class p14
{
    public static void main(String[] args) {
        for (int i=5;i>=1;i--)
        {

            for (int k=1;k<=i;k++)
            {
                System.out.print(k+" ");
            }

            System.out.println();
        }
    }
}
