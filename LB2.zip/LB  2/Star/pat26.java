import java.util.Scanner;


public class pat26
{ 

public static void main(String[]args){

Scanner sc=new Scanner(System.in);
System.out.println("Enter the lenth of STAR");
int n=sc.nextInt();

for(int l=1;l<=n;l++)
{
for(int j=0;j<=l;j++)
{
System.out.print(" ");
}

for(int k=n-1;k>=l;k--)
{
System.out.print("*");
}

for(int g=n;g>=l;g--)
{
System.out.print("*");
}
System.out.println();

}

}

}

