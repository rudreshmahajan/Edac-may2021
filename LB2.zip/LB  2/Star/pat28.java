//import java.util.Scanner;


public class pat28
{ 

public static void main(String[]args){

//Scanner sc=new Scanner(System.in);
//System.out.println("Enter the lenth of STAR");
//int n=sc.nextInt();

for(int i=1;i<=6;i++)
{

for(int m=1;m<=i;m++)            //for  1st star 
{
System.out.print("*");
}

System.out.println();

}


///////////////////////////////////////////////////////
for(int i=1;i<=5;i++)
{

for(int m=5;m>=i;m--)            //for  2nd star 
{
System.out.print("*");
}

System.out.println();
}










}

}