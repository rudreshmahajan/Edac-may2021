class p12
{ 

public static void main(String[]args){

char c=64;
for(int i=1;i<=5;i++)
{
	for(int k=5;k>=i;k--)   
{
	
System.out.print(char(c));
}

for(int j=1;j<=i;j++) 
{
	
System.out.print(i+" ");
}
c=64;


System.out.println();

}
}
}