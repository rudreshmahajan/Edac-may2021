
class p3
{
public static void main(String args[])
	 {
	  int a=50;
	 int b=3;
	 int div=a/b;
	 System.out.println("div of 74 and 36 is : "+div);
	 }
	 }