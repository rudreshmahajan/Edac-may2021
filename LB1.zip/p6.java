import java.util.Scanner;
class p6
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
int a=sc.nextInt();
int b=sc.nextInt();
int add=a+b;
int sub=a-b;
int mul=a*b;
int div=a/b;
int rem=a%b;
System.out.println("add=a+b :" +add);
System.out.println("sub=a-b :" +sub);
System.out.println("mul=a*b :" +mul);
System.out.println("div=a/b :" +div);
System.out.println("rem=a%b :"+rem);

}
}