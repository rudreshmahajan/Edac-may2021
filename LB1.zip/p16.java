class p16
{
	public static void main(String [] args)
	{
	        System.out.printf(" +\"\"\"\"\"+ \n");
		System.out.println("[| * * |]");
		System.out.println(" |  ^  | ");
		System.out.println(" | '-' | ");
		System.out.println(" +-----+ ");
	}
}