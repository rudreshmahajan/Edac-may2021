
class p13
{
	public static void main(String args[])
	{
		 double w = 5.5; 
       double h= 8.5;
		 double area=w*h;
		 double peri=2*(w+h);
		 System.out.println("area of rectangle is: "+area);
		  System.out.println("perimeter of rectangle is: "+peri);
}
}
		