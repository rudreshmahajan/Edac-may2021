
class p12
{
	public static void main(String args[])
	{
		 float w = 5.5f; 
         float h= 8.5f;
		 float area=0.5*(w*h);
		 float peri=2*(w+h);
		 System.out,println(area);
		  System.out,println(peri);
}
}
		