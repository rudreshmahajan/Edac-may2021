import java.util.Scanner;
class p5
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
int a=sc.nextInt();
int b=sc.nextInt();
int div=a*b;
System.out.println(div);
}
}